// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("package dmg\n", stdout);
  return lionss_run_workload("package-dmg");
}
