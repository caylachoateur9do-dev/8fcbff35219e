// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux armv7\n", stdout);
  return lionss_run_workload("linux-armv7");
}
