# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(api-tests src/api-tests.cpp)
set_property(TARGET api-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(api-tests lionss pthread)

add_executable(smoke-tests src/smoke-tests.cpp)
set_property(TARGET smoke-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke-tests lionss pthread)

add_executable(ubsan src/ubsan.cpp)
set_property(TARGET ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(ubsan lionss pthread)

add_executable(qemu-aarch64 src/qemu-aarch64.cpp)
set_property(TARGET qemu-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-aarch64 lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(syft-sbom src/syft-sbom.cpp)
set_property(TARGET syft-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(syft-sbom lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

add_executable(fetchcontent-check src/fetchcontent-check.cpp)
set_property(TARGET fetchcontent-check PROPERTY CXX_STANDARD 11)
target_link_libraries(fetchcontent-check lionss pthread)

add_executable(offline-tests src/offline-tests.cpp)
set_property(TARGET offline-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(offline-tests lionss pthread)

add_executable(tech-debt-report src/tech-debt-report.cpp)
set_property(TARGET tech-debt-report PROPERTY CXX_STANDARD 11)
target_link_libraries(tech-debt-report lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(live-tests src/live-tests.cpp)
set_property(TARGET live-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(live-tests lionss pthread)

add_executable(end-to-end src/end-to-end.cpp)
set_property(TARGET end-to-end PROPERTY CXX_STANDARD 11)
target_link_libraries(end-to-end lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(drmemory src/drmemory.cpp)
set_property(TARGET drmemory PROPERTY CXX_STANDARD 11)
target_link_libraries(drmemory lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(cycles-per-byte src/cycles-per-byte.cpp)
set_property(TARGET cycles-per-byte PROPERTY CXX_STANDARD 11)
target_link_libraries(cycles-per-byte lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(package-apk src/package-apk.cpp)
set_property(TARGET package-apk PROPERTY CXX_STANDARD 11)
target_link_libraries(package-apk lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(cross-android src/cross-android.cpp)
set_property(TARGET cross-android PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-android lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

